Sound pack downloaded from Freesound
----------------------------------------

"Audience"

This pack of sounds contains sounds by the following user:
 - Alcappuccino ( https://freesound.org/people/Alcappuccino/ )

You can find this pack online at: https://freesound.org/people/Alcappuccino/packs/16174/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 263024__alcappuccino__concert-ambience-applause-ending.wav
    * url: https://freesound.org/s/263024/
    * license: Creative Commons 0
  * 263023__alcappuccino__concert-ambience-applause-beginning.wav
    * url: https://freesound.org/s/263023/
    * license: Creative Commons 0
  * 262983__alcappuccino__pub-lachen50.wav
    * url: https://freesound.org/s/262983/
    * license: Creative Commons 0
  * 262982__alcappuccino__audience-laughing51.wav
    * url: https://freesound.org/s/262982/
    * license: Creative Commons 0
  * 262981__alcappuccino__audience-laughing22.wav
    * url: https://freesound.org/s/262981/
    * license: Creative Commons 0
  * 262980__alcappuccino__audience-laughing23.wav
    * url: https://freesound.org/s/262980/
    * license: Creative Commons 0
  * 262979__alcappuccino__audience-laughing41.wav
    * url: https://freesound.org/s/262979/
    * license: Creative Commons 0
  * 262978__alcappuccino__audience-laughing48.wav
    * url: https://freesound.org/s/262978/
    * license: Creative Commons 0
  * 262977__alcappuccino__audience-laughing-applause02.wav
    * url: https://freesound.org/s/262977/
    * license: Creative Commons 0
  * 262976__alcappuccino__audience-laughing-applause03.wav
    * url: https://freesound.org/s/262976/
    * license: Creative Commons 0
  * 262975__alcappuccino__audience-laughing-applause05.wav
    * url: https://freesound.org/s/262975/
    * license: Creative Commons 0
  * 262974__alcappuccino__audience-laughing-applause07.wav
    * url: https://freesound.org/s/262974/
    * license: Creative Commons 0


